"""Runtime, provider registry, and workspace state for HyperView."""

from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Literal
from urllib.parse import quote

from hyperview.core.dataset import Dataset
from hyperview.extensions import (
    ExtensionManifest,
    LoadedExtension,
    load_extension_tools,
    resolve_panel_source,
    unload_extension_modules,
)
from hyperview.storage.config import StorageConfig
from hyperview.storage.schema import parse_layout_dimension
from hyperview.tools import RunContext, ToolRegistry


def _now_ts() -> int:
    return int(time.time())


def _positive_int_or_none(value: int | None) -> int | None:
    if value is None:
        return None
    parsed = int(value)
    return parsed if parsed > 0 else None


_UNSET = object()


def get_runtime_config_dir() -> Path:
    datasets_dir = StorageConfig.default().datasets_dir
    config_dir = datasets_dir.parent
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_provider_registry_path() -> Path:
    return get_runtime_config_dir() / "providers.json"


def get_workspace_registry_path() -> Path:
    return get_runtime_config_dir() / "workspaces.json"


def _parse_import_path(import_path: str) -> tuple[str, str]:
    if ":" not in import_path:
        raise ValueError(f"import_path must use the form '<module>:<object>', got '{import_path}'")

    module_name, object_name = import_path.split(":", 1)
    if not module_name or not object_name:
        raise ValueError(f"import_path must use the form '<module>:<object>', got '{import_path}'")
    return module_name, object_name


def _import_from_path(import_path: str) -> Any:
    module_name, object_name = _parse_import_path(import_path)
    module = importlib.import_module(module_name)

    try:
        return getattr(module, object_name)
    except AttributeError as exc:
        raise ValueError(f"Object '{object_name}' not found in module '{module_name}'") from exc


@dataclass
class ProviderRegistration:
    alias: str
    kind: Literal["python"]
    import_path: str
    description: str | None = None
    defaults: dict[str, Any] = field(default_factory=dict)
    created_at: int = field(default_factory=_now_ts)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProviderRegistration:
        return cls(
            alias=str(data["alias"]),
            kind="python",
            import_path=str(data["import_path"]),
            description=data.get("description"),
            defaults=dict(data.get("defaults") or {}),
            created_at=int(data.get("created_at") or _now_ts()),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ProviderRegistry:
    """Persistent registry for user-defined embedding providers."""

    def __init__(self, path: Path | None = None):
        self.path = path or get_provider_registry_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._providers: dict[str, ProviderRegistration] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            self._providers = {}
            return

        data = json.loads(self.path.read_text())
        providers = data.get("providers") or []
        self._providers = {
            entry["alias"]: ProviderRegistration.from_dict(entry) for entry in providers
        }

    def _save(self) -> None:
        payload = {
            "providers": [
                provider.to_dict()
                for provider in sorted(self._providers.values(), key=lambda item: item.alias)
            ]
        }
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True))

    def list(self) -> list[ProviderRegistration]:
        return [self._providers[key] for key in sorted(self._providers)]

    def get(self, alias: str) -> ProviderRegistration | None:
        return self._providers.get(alias)

    def register_python(
        self,
        alias: str,
        import_path: str,
        *,
        description: str | None = None,
        defaults: dict[str, Any] | None = None,
        overwrite: bool = False,
    ) -> ProviderRegistration:
        alias = alias.strip()
        if not alias:
            raise ValueError("alias must be a non-empty string")

        existing = self._providers.get(alias)
        if existing is not None and not overwrite:
            raise ValueError(f"Provider alias already registered: {alias}")

        _parse_import_path(import_path)

        registration = ProviderRegistration(
            alias=alias,
            kind="python",
            import_path=import_path,
            description=description,
            defaults=dict(defaults or {}),
        )
        self._providers[alias] = registration
        self._save()
        return registration

    def unregister(self, alias: str) -> bool:
        removed = self._providers.pop(alias, None)
        if removed is None:
            return False
        self._save()
        return True

    def is_available(self, alias: str) -> bool:
        registration = self.get(alias)
        if registration is None:
            return False
        try:
            _import_from_path(registration.import_path)
        except Exception:
            return False
        return True

    def instantiate(self, alias: str, **kwargs: Any) -> Any:
        registration = self.get(alias)
        if registration is None:
            raise ValueError(f"Unknown custom provider alias: {alias}")

        target = _import_from_path(registration.import_path)
        resolved_kwargs = {**registration.defaults, **kwargs}

        if inspect.isclass(target):
            return target(**resolved_kwargs)

        if callable(target):
            created = target(**resolved_kwargs)
            return created

        if resolved_kwargs:
            raise ValueError(
                f"Custom provider '{alias}' resolved to a non-callable object and cannot accept kwargs"
            )
        return target


@dataclass
class CustomPanelSpec:
    id: str
    title: str
    module_file: str | None = None
    kind: Literal["module", "scatter", "builtin"] = "module"
    builtin_panel: Literal["samples"] | None = None
    extension: str | None = None
    extension_panel: str | None = None
    position: Literal["center", "right", "bottom"] = "right"
    layout_key: str | None = None
    geometry: str | None = None
    layout_dimension: int | None = None
    reference_panel_id: str | None = None
    direction: Literal["right", "left", "above", "below", "within"] | None = None
    width: int | None = None
    height: int | None = None
    min_width: int | None = None
    min_height: int | None = None
    max_width: int | None = None
    max_height: int | None = None
    visible: bool = True
    props: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CustomPanelSpec:
        kind = str(data.get("kind") or "module")
        if kind not in {"module", "scatter", "builtin"}:
            kind = "module"

        builtin_panel = data.get("builtin_panel")
        if builtin_panel is not None:
            builtin_panel = str(builtin_panel)
            if builtin_panel != "samples":
                builtin_panel = None

        position = str(data.get("position") or "right")
        if position not in {"center", "right", "bottom"}:
            position = "right"

        direction = data.get("direction")
        if direction is not None:
            direction = str(direction)
            if direction not in {"right", "left", "above", "below", "within"}:
                direction = None

        layout_dimension = data.get("layout_dimension")
        if layout_dimension is not None:
            try:
                layout_dimension = int(layout_dimension)
            except (TypeError, ValueError):
                layout_dimension = None

        def positive_int(key: str) -> int | None:
            value = data.get(key)
            if value is None:
                return None
            try:
                parsed = int(value)
            except (TypeError, ValueError):
                return None
            return parsed if parsed > 0 else None

        return cls(
            id=str(data["id"]),
            title=str(data["title"]),
            module_file=data.get("module_file"),
            kind=kind,  # type: ignore[arg-type]
            builtin_panel=builtin_panel,  # type: ignore[arg-type]
            extension=data.get("extension"),
            extension_panel=data.get("extension_panel"),
            position=position,  # type: ignore[arg-type]
            layout_key=data.get("layout_key"),
            geometry=data.get("geometry"),
            layout_dimension=layout_dimension,
            reference_panel_id=data.get("reference_panel_id"),
            direction=direction,  # type: ignore[arg-type]
            width=positive_int("width"),
            height=positive_int("height"),
            min_width=positive_int("min_width"),
            min_height=positive_int("min_height"),
            max_width=positive_int("max_width"),
            max_height=positive_int("max_height"),
            visible=bool(data.get("visible", True)),
            props=dict(data.get("props") or {}),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def resolved_module_file(self) -> Path | None:
        if not self.module_file:
            return None
        return Path(self.module_file).expanduser().resolve()


def _ensure_unique_panel_ids(panels: list[CustomPanelSpec]) -> None:
    seen: set[str] = set()
    duplicates: list[str] = []
    for panel in panels:
        if panel.id in seen and panel.id not in duplicates:
            duplicates.append(panel.id)
        seen.add(panel.id)
    if duplicates:
        duplicate_list = ", ".join(repr(panel_id) for panel_id in duplicates)
        raise ValueError(
            f"Custom panel ids must be unique. Duplicate panel id(s): {duplicate_list}."
        )


@dataclass
class LayoutViewState:
    camera_3d: dict[str, float] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LayoutViewState:
        camera_raw = data.get("camera_3d")
        camera_3d: dict[str, float] | None = None
        if isinstance(camera_raw, dict):
            parsed: dict[str, float] = {}
            required_keys = (
                "yaw",
                "pitch",
                "distance",
                "target_x",
                "target_y",
                "target_z",
                "ortho_scale",
            )
            for key in required_keys:
                value = camera_raw.get(key)
                if value is None:
                    parsed = {}
                    break
                try:
                    parsed[key] = float(value)
                except (TypeError, ValueError):
                    parsed = {}
                    break
            if len(parsed) == len(required_keys):
                camera_3d = parsed
        return cls(camera_3d=camera_3d)

    def to_dict(self) -> dict[str, Any]:
        return {"camera_3d": dict(self.camera_3d) if self.camera_3d is not None else None}


@dataclass
class SimilarityQueryState:
    anchor_sample_id: str
    layout_key: str | None = None
    space_key: str | None = None
    k: int = 18
    source: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimilarityQueryState | None:
        anchor_sample_id = str(data.get("anchor_sample_id") or "").strip()
        if not anchor_sample_id:
            return None
        try:
            k = int(data.get("k") or 18)
        except (TypeError, ValueError):
            k = 18
        return cls(
            anchor_sample_id=anchor_sample_id,
            layout_key=data.get("layout_key"),
            space_key=data.get("space_key"),
            k=max(1, min(k, 100)),
            source=data.get("source"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "anchor_sample_id": self.anchor_sample_id,
            "layout_key": self.layout_key,
            "space_key": self.space_key,
            "k": self.k,
            "source": self.source,
        }


@dataclass
class WorkspaceUiState:
    active_layout_key: str | None = None
    selected_ids: list[str] = field(default_factory=list)
    similarity_query: SimilarityQueryState | None = None
    custom_panels: list[CustomPanelSpec] = field(default_factory=list)
    has_explicit_view: bool = False
    active_panel_id: str | None = None
    layout_views: dict[str, LayoutViewState] = field(default_factory=dict)
    view_revision: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkspaceUiState:
        custom_panels: list[CustomPanelSpec] = []
        for entry in list(data.get("custom_panels") or []):
            panel = CustomPanelSpec.from_dict(entry)
            if panel.kind in {"scatter", "builtin"} or panel.module_file:
                custom_panels.append(panel)

        layout_views: dict[str, LayoutViewState] = {}
        raw_layout_views = data.get("layout_views") or {}
        if isinstance(raw_layout_views, dict):
            for layout_key, view_data in raw_layout_views.items():
                if isinstance(layout_key, str) and isinstance(view_data, dict):
                    layout_views[layout_key] = LayoutViewState.from_dict(view_data)

        similarity_query = SimilarityQueryState.from_dict(data.get("similarity_query") or {})
        selected_ids = list(data.get("selected_ids") or [])
        if similarity_query is not None:
            selected_ids = []

        return cls(
            active_layout_key=data.get("active_layout_key"),
            selected_ids=selected_ids,
            similarity_query=similarity_query,
            custom_panels=custom_panels,
            has_explicit_view=bool(data.get("has_explicit_view", False)),
            active_panel_id=data.get("active_panel_id"),
            layout_views=layout_views,
            view_revision=int(data.get("view_revision") or 0),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "active_layout_key": self.active_layout_key,
            "selected_ids": list(self.selected_ids),
            "similarity_query": (
                self.similarity_query.to_dict() if self.similarity_query is not None else None
            ),
            "custom_panels": [panel.to_dict() for panel in self.custom_panels],
            "has_explicit_view": self.has_explicit_view,
            "active_panel_id": self.active_panel_id,
            "layout_views": {
                layout_key: view.to_dict() for layout_key, view in sorted(self.layout_views.items())
            },
            "view_revision": self.view_revision,
        }


@dataclass
class WorkspaceState:
    id: str
    dataset_name: str | None = None
    ui: WorkspaceUiState = field(default_factory=WorkspaceUiState)
    created_at: int = field(default_factory=_now_ts)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkspaceState:
        return cls(
            id=str(data["id"]),
            dataset_name=data.get("dataset_name"),
            ui=WorkspaceUiState.from_dict(data.get("ui") or {}),
            created_at=int(data.get("created_at") or _now_ts()),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "dataset_name": self.dataset_name,
            "ui": self.ui.to_dict(),
            "created_at": self.created_at,
        }


class WorkspaceRegistry:
    """Persistent registry for HyperView workspaces."""

    def __init__(self, path: Path | None = None):
        self.path = path or get_workspace_registry_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.active_workspace_id: str | None = None
        self._workspaces: dict[str, WorkspaceState] = {}
        self._load()
        if not self._workspaces:
            self.create_workspace("default", activate=True)

    def _load(self) -> None:
        if not self.path.exists():
            self.active_workspace_id = None
            self._workspaces = {}
            return

        data = json.loads(self.path.read_text())
        self.active_workspace_id = data.get("active_workspace_id")
        self._workspaces = {
            entry["id"]: WorkspaceState.from_dict(entry)
            for entry in list(data.get("workspaces") or [])
        }

    def _save(self) -> None:
        payload = {
            "active_workspace_id": self.active_workspace_id,
            "workspaces": [
                workspace.to_dict()
                for workspace in sorted(self._workspaces.values(), key=lambda item: item.id)
            ],
        }
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True))

    def list(self) -> list[WorkspaceState]:
        return [self._workspaces[key] for key in sorted(self._workspaces)]

    def get(self, workspace_id: str) -> WorkspaceState | None:
        return self._workspaces.get(workspace_id)

    def create_workspace(self, workspace_id: str, *, activate: bool = False) -> WorkspaceState:
        workspace_id = workspace_id.strip()
        if not workspace_id:
            raise ValueError("workspace_id must be a non-empty string")
        if workspace_id in self._workspaces:
            raise ValueError(f"Workspace already exists: {workspace_id}")

        workspace = WorkspaceState(id=workspace_id)
        self._workspaces[workspace_id] = workspace
        if activate or self.active_workspace_id is None:
            self.active_workspace_id = workspace_id
        self._save()
        return workspace

    def ensure_workspace(self, workspace_id: str, *, activate: bool = False) -> WorkspaceState:
        workspace = self.get(workspace_id)
        if workspace is not None:
            if activate:
                self.active_workspace_id = workspace_id
                self._save()
            return workspace
        return self.create_workspace(workspace_id, activate=activate)

    def set_active_workspace(self, workspace_id: str) -> WorkspaceState:
        workspace = self.get(workspace_id)
        if workspace is None:
            raise ValueError(f"Unknown workspace: {workspace_id}")
        self.active_workspace_id = workspace_id
        self._save()
        return workspace

    def delete_workspace(self, workspace_id: str) -> WorkspaceState | None:
        workspace = self.get(workspace_id)
        if workspace is None:
            raise ValueError(f"Unknown workspace: {workspace_id}")
        if len(self._workspaces) <= 1:
            raise ValueError("Cannot delete the last remaining workspace")

        del self._workspaces[workspace_id]

        if self.active_workspace_id == workspace_id:
            remaining_ids = sorted(self._workspaces)
            self.active_workspace_id = remaining_ids[0] if remaining_ids else None

        self._save()
        if self.active_workspace_id is None:
            return None
        return self._workspaces[self.active_workspace_id]

    def set_dataset(self, workspace_id: str, dataset_name: str) -> WorkspaceState:
        workspace = self.ensure_workspace(workspace_id)
        workspace.dataset_name = dataset_name
        self._save()
        return workspace

    def update_workspace(self, workspace: WorkspaceState) -> None:
        self._workspaces[workspace.id] = workspace
        self._save()


@dataclass
class JobState:
    id: str
    kind: str
    workspace_id: str
    dataset_name: str | None
    status: Literal["queued", "running", "completed", "failed"] = "queued"
    created_at: int = field(default_factory=_now_ts)
    started_at: int | None = None
    finished_at: int | None = None
    result: dict[str, Any] | None = None
    error: str | None = None
    params: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ExtensionInstallation:
    """Bookkeeping for an installed extension (in-memory, per-process)."""

    manifest: ExtensionManifest
    loaded: LoadedExtension
    workspace_id: str
    panel_ids: list[str] = field(default_factory=list)
    add_panels: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.manifest.name,
            "folder": str(self.manifest.folder),
            "description": self.manifest.description,
            "workspace_id": self.workspace_id,
            "panels": list(self.panel_ids),
            "panel_definitions": [
                {
                    "id": panel.id,
                    "title": panel.title,
                    "position": panel.position,
                    "file": panel.file,
                }
                for panel in self.manifest.panels
            ],
            "tools": [record.to_dict() for record in self.loaded.tools],
        }


class HyperViewRuntime:
    """Mutable application runtime for multi-workspace HyperView sessions."""

    def __init__(
        self,
        *,
        provider_registry: ProviderRegistry | None = None,
        workspace_registry: WorkspaceRegistry | None = None,
    ):
        self.runtime_id = uuid.uuid4().hex
        self.provider_registry = provider_registry or ProviderRegistry()
        self.workspace_registry = workspace_registry or WorkspaceRegistry()
        self.tools = ToolRegistry()
        self._extensions: dict[str, ExtensionInstallation] = {}
        self._dataset_cache: dict[str, Dataset] = {}
        self._jobs: dict[str, JobState] = {}
        self._panel_module_revisions: dict[tuple[str, str, str], str] = {}
        self._lock = threading.RLock()
        self._version = 1
        self._version_source_client_id: str | None = None

    @property
    def version(self) -> int:
        return self._version

    @property
    def version_source_client_id(self) -> str | None:
        return self._version_source_client_id

    def _bump_version(self, *, source_client_id: str | None = None) -> None:
        with self._lock:
            self._version += 1
            self._version_source_client_id = source_client_id

    def _panel_module_revision(self, panel: CustomPanelSpec) -> str | None:
        module_file = panel.resolved_module_file()
        if module_file is None:
            return None
        try:
            return hashlib.sha256(module_file.read_bytes()).hexdigest()[:16]
        except OSError:
            return "missing"

    def _sync_panel_module_revisions_locked(self) -> None:
        changed = False
        seen: set[tuple[str, str, str]] = set()

        for workspace in self.workspace_registry.list():
            for panel in workspace.ui.custom_panels:
                module_file = panel.resolved_module_file()
                if module_file is None:
                    continue

                key = (workspace.id, panel.id, str(module_file))
                revision = self._panel_module_revision(panel)
                if revision is None:
                    continue

                seen.add(key)
                previous = self._panel_module_revisions.get(key)
                self._panel_module_revisions[key] = revision
                if previous is not None and previous != revision:
                    changed = True

        for key in list(self._panel_module_revisions):
            if key not in seen:
                del self._panel_module_revisions[key]

        if changed:
            self._bump_version()

    def list_available_datasets(self) -> list[str]:
        datasets_dir = StorageConfig.default().datasets_dir
        datasets_dir.mkdir(parents=True, exist_ok=True)
        return sorted([path.name for path in datasets_dir.iterdir() if path.is_dir()])

    def attach_dataset_instance(
        self,
        workspace_id: str,
        dataset: Dataset,
        *,
        activate_workspace: bool = True,
    ) -> None:
        with self._lock:
            previous_workspace = self.workspace_registry.get(workspace_id)
            previous_dataset_name = (
                previous_workspace.dataset_name if previous_workspace is not None else None
            )
            self._dataset_cache[dataset.name] = dataset
            workspace = self.workspace_registry.set_dataset(workspace_id, dataset.name)
            if previous_dataset_name != dataset.name:
                workspace.ui.active_layout_key = None
                workspace.ui.selected_ids = []
                workspace.ui.similarity_query = None
                workspace.ui.layout_views = {}
                self.workspace_registry.update_workspace(workspace)
            if activate_workspace:
                self.workspace_registry.set_active_workspace(workspace_id)
            self._bump_version()

    def create_workspace(self, workspace_id: str, *, activate: bool = False) -> WorkspaceState:
        with self._lock:
            workspace = self.workspace_registry.create_workspace(workspace_id, activate=activate)
            self._bump_version()
            return workspace

    def set_active_workspace(self, workspace_id: str) -> WorkspaceState:
        with self._lock:
            workspace = self.workspace_registry.set_active_workspace(workspace_id)
            self._bump_version()
            return workspace

    def set_workspace_dataset(
        self,
        workspace_id: str,
        dataset_name: str,
    ) -> WorkspaceState:
        with self._lock:
            previous_workspace = self.workspace_registry.get(workspace_id)
            previous_dataset_name = (
                previous_workspace.dataset_name if previous_workspace is not None else None
            )
            workspace = self.workspace_registry.set_dataset(workspace_id, dataset_name)
            if previous_dataset_name != dataset_name:
                workspace.ui.active_layout_key = None
                workspace.ui.selected_ids = []
                workspace.ui.similarity_query = None
                workspace.ui.layout_views = {}
                self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def get_workspace(self, workspace_id: str | None = None) -> WorkspaceState:
        resolved_workspace_id = workspace_id or self.workspace_registry.active_workspace_id
        if resolved_workspace_id is None:
            raise ValueError("No active workspace")
        workspace = self.workspace_registry.get(resolved_workspace_id)
        if workspace is None:
            raise ValueError(f"Unknown workspace: {resolved_workspace_id}")
        return workspace

    def get_dataset(
        self, workspace_id: str | None = None, dataset_name: str | None = None
    ) -> Dataset:
        workspace = self.get_workspace(workspace_id)
        resolved_dataset_name = dataset_name or workspace.dataset_name
        if not resolved_dataset_name:
            raise ValueError(f"Workspace '{workspace.id}' has no active dataset")

        cached = self._dataset_cache.get(resolved_dataset_name)
        if cached is not None:
            return cached

        dataset = Dataset(resolved_dataset_name)
        self._dataset_cache[resolved_dataset_name] = dataset
        return dataset

    def set_active_layout(self, workspace_id: str, layout_key: str | None) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            workspace.ui.active_layout_key = layout_key
            self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def set_selection(self, workspace_id: str, sample_ids: list[str]) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            workspace.ui.selected_ids = list(dict.fromkeys(sample_ids))
            if (
                workspace.ui.similarity_query is not None
                and workspace.ui.similarity_query.anchor_sample_id not in workspace.ui.selected_ids
            ):
                workspace.ui.similarity_query = None
            self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def set_similarity_query(
        self,
        workspace_id: str,
        query: SimilarityQueryState | None,
    ) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            workspace.ui.similarity_query = query
            if query is not None:
                workspace.ui.selected_ids = []
            self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def patch_ui_state(
        self,
        workspace_id: str,
        *,
        set_active_layout: bool = False,
        active_layout_key: str | None = None,
        set_selection: bool = False,
        selected_ids: list[str] | None = None,
        set_similarity_query: bool = False,
        similarity_query: SimilarityQueryState | None = None,
        source_client_id: str | None = None,
    ) -> WorkspaceState:
        """Apply multiple UI-state updates under one runtime version bump."""
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            changed = False
            next_selected_ids = (
                list(dict.fromkeys(selected_ids or []))
                if set_selection
                else list(workspace.ui.selected_ids)
            )

            if set_active_layout and workspace.ui.active_layout_key != active_layout_key:
                workspace.ui.active_layout_key = active_layout_key
                changed = True

            if set_selection:
                if workspace.ui.selected_ids != next_selected_ids:
                    workspace.ui.selected_ids = next_selected_ids
                    changed = True
                if (
                    workspace.ui.similarity_query is not None
                    and workspace.ui.similarity_query.anchor_sample_id
                    not in workspace.ui.selected_ids
                ):
                    workspace.ui.similarity_query = None
                    changed = True

            if set_similarity_query and workspace.ui.similarity_query != similarity_query:
                workspace.ui.similarity_query = similarity_query
                changed = True
            if set_similarity_query and similarity_query is not None and workspace.ui.selected_ids:
                workspace.ui.selected_ids = []
                changed = True

            if changed:
                self.workspace_registry.update_workspace(workspace)
                self._bump_version(source_client_id=source_client_id)
            return workspace

    def resolve_similarity_query(
        self,
        workspace_id: str,
        sample_id: str,
        *,
        layout_key: str | None = None,
        space_key: str | None = None,
        k: int = 18,
        source: str | None = None,
    ) -> SimilarityQueryState:
        dataset = self.get_dataset(workspace_id=workspace_id)
        try:
            dataset[sample_id]
        except KeyError as exc:
            raise KeyError(f"Sample not found: {sample_id}") from exc

        resolved_space_key = space_key
        if layout_key is not None:
            layout = next(
                (item for item in dataset.list_layouts() if item.layout_key == layout_key),
                None,
            )
            if layout is None:
                raise LookupError(f"Layout not found: {layout_key}")
            if resolved_space_key is not None and resolved_space_key != layout.space_key:
                raise ValueError("space_key does not match the requested layout_key")
            resolved_space_key = layout.space_key

        if resolved_space_key is not None:
            space = next(
                (item for item in dataset.list_spaces() if item.space_key == resolved_space_key),
                None,
            )
            if space is None:
                raise LookupError(f"Space not found: {resolved_space_key}")

        try:
            limit = int(k)
        except (TypeError, ValueError):
            limit = 18

        return SimilarityQueryState(
            anchor_sample_id=sample_id,
            layout_key=layout_key,
            space_key=resolved_space_key,
            k=max(1, min(limit, 100)),
            source=source,
        )

    def set_layout_view(
        self,
        workspace_id: str,
        layout_key: str,
        view: LayoutViewState,
    ) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            current = workspace.ui.layout_views.get(layout_key)
            if current is not None and current.to_dict() == view.to_dict():
                return workspace
            workspace.ui.layout_views[layout_key] = view
            self.workspace_registry.update_workspace(workspace)
            # Camera saves are high-frequency local UI state; avoid forcing
            # runtime snapshots that can overwrite in-progress selection state.
            return workspace

    def build_custom_panel(
        self,
        workspace_id: str,
        *,
        panel_id: str,
        kind: Literal["extension", "scatter", "module", "builtin"],
        title: str | None = None,
        builtin_panel: Literal["samples"] | None = None,
        extension: str | None = None,
        extension_panel: str | None = None,
        layout_key: str | None = None,
        position: str = "right",
        reference_panel_id: str | None = None,
        direction: str | None = None,
        width: int | None = None,
        height: int | None = None,
        min_width: int | None = None,
        min_height: int | None = None,
        max_width: int | None = None,
        max_height: int | None = None,
        visible: bool = True,
        props: dict[str, Any] | None = None,
        geometry: str | None = None,
        layout_dimension: int | None = None,
        require_resolved_layout: bool = True,
    ) -> CustomPanelSpec:
        """Resolve a transport-level panel request into a runtime panel spec."""

        if position not in {"center", "right", "bottom"}:
            raise ValueError("position must be one of center, right, bottom")
        if direction is not None and direction not in {
            "right",
            "left",
            "above",
            "below",
            "within",
        }:
            raise ValueError("direction must be one of right, left, above, below, within")

        if kind == "module":
            raise ValueError(
                "Direct module panels are no longer a public API. "
                "Package custom panel modules as extensions and add them with kind='extension'."
            )

        if kind == "builtin":
            if builtin_panel != "samples":
                raise ValueError("builtin_panel must be 'samples'")
            return CustomPanelSpec(
                id=panel_id,
                title=title or "Samples",
                kind="builtin",
                builtin_panel="samples",
                position=position,  # type: ignore[arg-type]
                reference_panel_id=reference_panel_id,
                direction=direction,  # type: ignore[arg-type]
                width=_positive_int_or_none(width),
                height=_positive_int_or_none(height),
                min_width=_positive_int_or_none(min_width),
                min_height=_positive_int_or_none(min_height),
                max_width=_positive_int_or_none(max_width),
                max_height=_positive_int_or_none(max_height),
                visible=visible,
                props=dict(props or {}),
            )

        if kind == "extension":
            if not extension:
                raise ValueError("extension is required for extension panels")
            if not extension_panel:
                raise ValueError("extension_panel is required for extension panels")
            installation = self.get_extension(extension)
            if installation is None:
                raise LookupError(f"Extension not found: {extension}")
            manifest_panel = next(
                (panel for panel in installation.manifest.panels if panel.id == extension_panel),
                None,
            )
            if manifest_panel is None:
                raise LookupError(f"Extension panel not found: {extension}/{extension_panel}")
            module_file = resolve_panel_source(
                installation.manifest.folder,
                manifest_panel.file,
            )
            return CustomPanelSpec(
                id=panel_id,
                title=title or manifest_panel.title,
                kind="module",
                extension=extension,
                extension_panel=extension_panel,
                module_file=str(module_file),
                position=position,  # type: ignore[arg-type]
                reference_panel_id=reference_panel_id,
                direction=direction,  # type: ignore[arg-type]
                width=_positive_int_or_none(width),
                height=_positive_int_or_none(height),
                min_width=_positive_int_or_none(min_width),
                min_height=_positive_int_or_none(min_height),
                max_width=_positive_int_or_none(max_width),
                max_height=_positive_int_or_none(max_height),
                visible=visible,
                props=dict(props or {}),
            )

        if kind == "scatter":
            if not layout_key:
                raise ValueError("layout_key is required for scatter panels")
            if geometry is None or layout_dimension is None:
                try:
                    dataset = self.get_dataset(workspace_id)
                except ValueError:
                    if require_resolved_layout:
                        raise
                    dataset = None
                layout_info = None
                if dataset is not None:
                    layout_info = next(
                        (
                            layout
                            for layout in dataset.list_layouts()
                            if layout.layout_key == layout_key
                        ),
                        None,
                    )
                if layout_info is None:
                    if require_resolved_layout:
                        raise LookupError(f"Layout not found: {layout_key}")
                else:
                    geometry = geometry or layout_info.geometry
                    layout_dimension = (
                        layout_dimension
                        if layout_dimension is not None
                        else parse_layout_dimension(layout_info.layout_key)
                    )
            if not title:
                raise ValueError("title is required for scatter panels")
            return CustomPanelSpec(
                id=panel_id,
                title=title,
                kind="scatter",
                position=position,  # type: ignore[arg-type]
                layout_key=layout_key,
                geometry=geometry,
                layout_dimension=layout_dimension,
                reference_panel_id=reference_panel_id,
                direction=direction,  # type: ignore[arg-type]
                width=_positive_int_or_none(width),
                height=_positive_int_or_none(height),
                min_width=_positive_int_or_none(min_width),
                min_height=_positive_int_or_none(min_height),
                max_width=_positive_int_or_none(max_width),
                max_height=_positive_int_or_none(max_height),
                visible=visible,
                props=dict(props or {}),
            )

        raise ValueError(f"Unsupported panel kind: {kind}")

    def add_runtime_panel(
        self,
        workspace_id: str,
        *,
        panel_id: str,
        kind: Literal["extension", "scatter", "module", "builtin"],
        title: str | None = None,
        builtin_panel: Literal["samples"] | None = None,
        extension: str | None = None,
        extension_panel: str | None = None,
        layout_key: str | None = None,
        position: str = "right",
        reference_panel_id: str | None = None,
        direction: str | None = None,
        width: int | None = None,
        height: int | None = None,
        min_width: int | None = None,
        min_height: int | None = None,
        max_width: int | None = None,
        max_height: int | None = None,
        visible: bool = True,
        props: dict[str, Any] | None = None,
        geometry: str | None = None,
        layout_dimension: int | None = None,
        require_resolved_layout: bool = True,
    ) -> WorkspaceState:
        panel = self.build_custom_panel(
            workspace_id,
            panel_id=panel_id,
            kind=kind,
            title=title,
            builtin_panel=builtin_panel,
            extension=extension,
            extension_panel=extension_panel,
            layout_key=layout_key,
            position=position,
            reference_panel_id=reference_panel_id,
            direction=direction,
            width=width,
            height=height,
            min_width=min_width,
            min_height=min_height,
            max_width=max_width,
            max_height=max_height,
            visible=visible,
            props=props,
            geometry=geometry,
            layout_dimension=layout_dimension,
            require_resolved_layout=require_resolved_layout,
        )
        return self.add_custom_panel(workspace_id, panel)

    def add_custom_panel(self, workspace_id: str, panel: CustomPanelSpec) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            panels = [
                existing for existing in workspace.ui.custom_panels if existing.id != panel.id
            ]
            panels.append(panel)
            workspace.ui.custom_panels = panels
            workspace.ui.view_revision += 1
            self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def update_custom_panel(
        self,
        workspace_id: str,
        panel_id: str,
        *,
        title: str | None = None,
        position: Literal["center", "right", "bottom"] | None = None,
        reference_panel_id: str | None | object = _UNSET,
        direction: Literal["right", "left", "above", "below", "within"] | None | object = _UNSET,
        width: int | None | object = _UNSET,
        height: int | None | object = _UNSET,
        min_width: int | None | object = _UNSET,
        min_height: int | None | object = _UNSET,
        max_width: int | None | object = _UNSET,
        max_height: int | None | object = _UNSET,
        visible: bool | None = None,
        active: bool | None = None,
        props: dict[str, Any] | None = None,
    ) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            next_panels: list[CustomPanelSpec] = []
            found = False
            changed = False

            for panel in workspace.ui.custom_panels:
                if panel.id != panel_id:
                    next_panels.append(panel)
                    continue

                found = True
                next_panel = panel
                if title is not None and title != panel.title:
                    next_panel = replace(next_panel, title=title)
                    changed = True
                if position is not None:
                    if position not in {"center", "right", "bottom"}:
                        raise ValueError("position must be one of center, right, bottom")
                    if position != panel.position:
                        next_panel = replace(next_panel, position=position)
                        changed = True
                if reference_panel_id is not _UNSET:
                    next_reference_panel_id = (
                        None if reference_panel_id is None else str(reference_panel_id)
                    )
                    if next_reference_panel_id != panel.reference_panel_id:
                        next_panel = replace(
                            next_panel,
                            reference_panel_id=next_reference_panel_id,
                        )
                        changed = True
                if direction is not _UNSET:
                    if direction is not None and direction not in {
                        "right",
                        "left",
                        "above",
                        "below",
                        "within",
                    }:
                        raise ValueError("direction must be one of right, left, above, below, within")
                    next_direction = direction if direction is None else str(direction)
                    if next_direction != panel.direction:
                        next_panel = replace(next_panel, direction=next_direction)
                        changed = True
                for field_name, value in {
                    "width": width,
                    "height": height,
                    "min_width": min_width,
                    "min_height": min_height,
                    "max_width": max_width,
                    "max_height": max_height,
                }.items():
                    if value is _UNSET:
                        continue
                    parsed_value = None if value is None else _positive_int_or_none(value)  # type: ignore[arg-type]
                    if getattr(panel, field_name) != parsed_value:
                        next_panel = replace(next_panel, **{field_name: parsed_value})
                        changed = True
                if visible is not None and visible != panel.visible:
                    next_panel = replace(next_panel, visible=visible)
                    changed = True
                if props is not None and props != panel.props:
                    next_panel = replace(next_panel, props=dict(props))
                    changed = True
                next_panels.append(next_panel)

            if not found:
                raise KeyError(f"Panel not found: {panel_id}")

            if active is True and workspace.ui.active_panel_id != panel_id:
                workspace.ui.active_panel_id = panel_id
                changed = True
            elif active is False and workspace.ui.active_panel_id == panel_id:
                workspace.ui.active_panel_id = None
                changed = True

            if visible is False and workspace.ui.active_panel_id == panel_id:
                workspace.ui.active_panel_id = None
                changed = True

            if changed:
                workspace.ui.custom_panels = next_panels
                workspace.ui.view_revision += 1
                self.workspace_registry.update_workspace(workspace)
                self._bump_version()
            return workspace

    def replace_custom_panels(
        self,
        workspace_id: str,
        panels: list[CustomPanelSpec],
        *,
        bump_view_revision: bool = True,
        has_explicit_view: bool | None = None,
        active_panel_id: str | None = None,
    ) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            next_panels = list(panels)
            _ensure_unique_panel_ids(next_panels)
            next_has_explicit_view = (
                workspace.ui.has_explicit_view if has_explicit_view is None else has_explicit_view
            )
            next_active_panel_id = active_panel_id
            if next_active_panel_id is not None and not any(
                panel.id == next_active_panel_id for panel in next_panels
            ):
                raise ValueError(f"Active panel is not in the view: {next_active_panel_id}")

            if [panel.to_dict() for panel in workspace.ui.custom_panels] == [
                panel.to_dict() for panel in next_panels
            ] and workspace.ui.has_explicit_view == next_has_explicit_view and workspace.ui.active_panel_id == next_active_panel_id:
                return workspace

            workspace.ui.custom_panels = next_panels
            workspace.ui.has_explicit_view = next_has_explicit_view
            workspace.ui.active_panel_id = next_active_panel_id
            if bump_view_revision:
                workspace.ui.view_revision += 1
            self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def remove_custom_panel(self, workspace_id: str, panel_id: str) -> WorkspaceState:
        with self._lock:
            workspace = self.get_workspace(workspace_id)
            workspace.ui.custom_panels = [
                panel for panel in workspace.ui.custom_panels if panel.id != panel_id
            ]
            if workspace.ui.active_panel_id == panel_id:
                workspace.ui.active_panel_id = None
            workspace.ui.view_revision += 1
            self.workspace_registry.update_workspace(workspace)
            self._bump_version()
            return workspace

    def get_custom_panel(self, workspace_id: str, panel_id: str) -> CustomPanelSpec:
        workspace = self.get_workspace(workspace_id)
        for panel in workspace.ui.custom_panels:
            if panel.id == panel_id:
                return panel
        raise ValueError(f"Unknown panel '{panel_id}' for workspace '{workspace.id}'")

    def register_job(
        self,
        *,
        kind: str,
        workspace_id: str,
        dataset_name: str | None,
        params: dict[str, Any],
    ) -> JobState:
        job = JobState(
            id=uuid.uuid4().hex,
            kind=kind,
            workspace_id=workspace_id,
            dataset_name=dataset_name,
            params=params,
        )
        with self._lock:
            self._jobs[job.id] = job
            self._bump_version()
        return job

    def list_jobs(self) -> list[JobState]:
        with self._lock:
            return [self._jobs[key] for key in sorted(self._jobs)]

    def get_job(self, job_id: str) -> JobState | None:
        with self._lock:
            return self._jobs.get(job_id)

    def submit_job(
        self,
        *,
        kind: str,
        workspace_id: str,
        dataset_name: str | None,
        params: dict[str, Any],
        target: Any,
    ) -> JobState:
        job = self.register_job(
            kind=kind, workspace_id=workspace_id, dataset_name=dataset_name, params=params
        )

        def runner() -> None:
            with self._lock:
                current = self._jobs[job.id]
                current.status = "running"
                current.started_at = _now_ts()
                self._bump_version()

            try:
                result = target()
            except Exception as exc:  # pragma: no cover - error path depends on runtime failures
                with self._lock:
                    current = self._jobs[job.id]
                    current.status = "failed"
                    current.error = f"{type(exc).__name__}: {exc}"
                    current.finished_at = _now_ts()
                    self._bump_version()
                return

            with self._lock:
                current = self._jobs[job.id]
                current.status = "completed"
                current.result = result
                current.finished_at = _now_ts()
                self._bump_version()

        thread = threading.Thread(target=runner, name=f"hyperview-job-{job.id[:8]}", daemon=True)
        thread.start()
        return job

    def submit_embedding_job(
        self,
        *,
        workspace_id: str,
        dataset_name: str,
        model: str,
        provider: str | None = None,
        checkpoint: str | None = None,
        provider_kwargs: dict[str, Any] | None = None,
        layouts: list[str] | None = None,
        method: str = "umap",
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        metric: str = "cosine",
        activate_layout: bool = True,
    ) -> JobState:
        provider_kwargs = dict(provider_kwargs or {})

        def run() -> dict[str, Any]:
            dataset = self.get_dataset(workspace_id, dataset_name)
            space_key = dataset.compute_embeddings(
                model=model,
                provider=provider,
                checkpoint=checkpoint,
                show_progress=True,
                _provider_registry=self.provider_registry,
                **provider_kwargs,
            )

            layout_keys: list[str] = []
            for layout in layouts or []:
                layout_key = dataset.compute_visualization(
                    space_key=space_key,
                    method=method,
                    layout=layout,
                    n_neighbors=n_neighbors,
                    min_dist=min_dist,
                    metric=metric,
                )
                layout_keys.append(layout_key)

            self.set_workspace_dataset(workspace_id, dataset_name)
            if activate_layout and layout_keys:
                self.set_active_layout(workspace_id, layout_keys[0])

            return {
                "space_key": space_key,
                "layout_keys": layout_keys,
            }

        return self.submit_job(
            kind="embeddings.compute",
            workspace_id=workspace_id,
            dataset_name=dataset_name,
            params={
                "model": model,
                "provider": provider,
                "checkpoint": checkpoint,
                "layouts": list(layouts or []),
            },
            target=run,
        )

    def submit_layout_job(
        self,
        *,
        workspace_id: str,
        dataset_name: str,
        space_key: str | None,
        layouts: list[str],
        method: str = "umap",
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        metric: str = "cosine",
        activate_layout: bool = True,
    ) -> JobState:
        def run() -> dict[str, Any]:
            dataset = self.get_dataset(workspace_id, dataset_name)
            layout_keys: list[str] = []
            for layout in layouts:
                layout_key = dataset.compute_visualization(
                    space_key=space_key,
                    method=method,
                    layout=layout,
                    n_neighbors=n_neighbors,
                    min_dist=min_dist,
                    metric=metric,
                )
                layout_keys.append(layout_key)
            if activate_layout and layout_keys:
                self.set_active_layout(workspace_id, layout_keys[0])
            return {"layout_keys": layout_keys}

        return self.submit_job(
            kind="layouts.compute",
            workspace_id=workspace_id,
            dataset_name=dataset_name,
            params={"space_key": space_key, "layouts": layouts},
            target=run,
        )

    def get_panel_payload(self, workspace_id: str, panel: CustomPanelSpec) -> dict[str, Any]:
        module_file = panel.resolved_module_file()
        if module_file is None:
            return {"module_src": None}

        revision = self._panel_module_revision(panel) or str(self.version)
        return {
            "module_src": "/api/panels/content/"
            f"{quote(workspace_id, safe='')}/"
            f"{quote(panel.id, safe='')}/"
            f"{quote(module_file.name, safe='')}"
            f"?hv_rev={quote(revision, safe='')}",
        }

    # ------------------------------------------------------------------
    # Extensions and tools
    # ------------------------------------------------------------------

    def list_extensions(self) -> list[ExtensionInstallation]:
        with self._lock:
            return [self._extensions[key] for key in sorted(self._extensions)]

    def get_extension(self, name: str) -> ExtensionInstallation | None:
        with self._lock:
            return self._extensions.get(name)

    def install_extension(
        self,
        workspace_id: str,
        folder: Path,
        *,
        add_panels: bool = False,
    ) -> ExtensionInstallation:
        """Load an extension folder and register its tools + panels."""

        manifest = ExtensionManifest.load(folder)
        loaded = load_extension_tools(manifest)
        prepared_panels: list[CustomPanelSpec] = []
        for panel_entry in manifest.panels:
            panel_file = resolve_panel_source(manifest.folder, panel_entry.file)
            prepared_panels.append(
                CustomPanelSpec(
                    id=panel_entry.id,
                    title=panel_entry.title,
                    extension=manifest.name,
                    extension_panel=panel_entry.id,
                    module_file=str(panel_file),
                    position=panel_entry.position,  # type: ignore[arg-type]
                )
            )

        with self._lock:
            self.get_workspace(workspace_id)

            previous_installation = self._extensions.get(manifest.name)
            previous_workspace_panels: list[CustomPanelSpec] | None = None
            if previous_installation is not None:
                try:
                    previous_workspace = self.get_workspace(previous_installation.workspace_id)
                except ValueError:
                    previous_workspace = None
                if previous_workspace is not None:
                    previous_workspace_panels = list(previous_workspace.ui.custom_panels)

            installed_panel_ids: list[str] = []
            try:
                if previous_installation is not None:
                    self._uninstall_extension_locked(manifest.name)

                for record in loaded.tools:
                    self.tools.register(record)

                if add_panels:
                    for panel in prepared_panels:
                        self._add_custom_panel_locked(workspace_id, panel)
                        installed_panel_ids.append(panel.id)

                installation = ExtensionInstallation(
                    manifest=manifest,
                    loaded=loaded,
                    workspace_id=workspace_id,
                    panel_ids=list(installed_panel_ids),
                    add_panels=add_panels,
                )
                self._extensions[manifest.name] = installation
                self._bump_version()
                return installation
            except Exception:
                if installed_panel_ids:
                    workspace = self.get_workspace(workspace_id)
                    workspace.ui.custom_panels = [
                        panel
                        for panel in workspace.ui.custom_panels
                        if panel.id not in installed_panel_ids
                    ]
                    workspace.ui.view_revision += 1
                    self.workspace_registry.update_workspace(workspace)

                self.tools.unregister_by_extension(manifest.name)
                unload_extension_modules(loaded)

                if previous_installation is not None:
                    self._extensions[manifest.name] = previous_installation
                    for record in previous_installation.loaded.tools:
                        self.tools.register(record)

                    if previous_workspace_panels is not None:
                        workspace = self.get_workspace(previous_installation.workspace_id)
                        workspace.ui.custom_panels = previous_workspace_panels
                        workspace.ui.view_revision += 1
                        self.workspace_registry.update_workspace(workspace)

                raise

    def uninstall_extension(self, name: str) -> ExtensionInstallation | None:
        with self._lock:
            return self._uninstall_extension_locked(name)

    def _uninstall_extension_locked(self, name: str) -> ExtensionInstallation | None:
        installation = self._extensions.pop(name, None)
        if installation is None:
            return None

        try:
            workspace = self.get_workspace(installation.workspace_id)
        except ValueError:
            workspace = None

        if workspace is not None:
            workspace.ui.custom_panels = [
                panel
                for panel in workspace.ui.custom_panels
                if panel.id not in installation.panel_ids
            ]
            workspace.ui.view_revision += 1
            self.workspace_registry.update_workspace(workspace)

        self.tools.unregister_by_extension(name)
        unload_extension_modules(installation.loaded)
        self._bump_version()
        return installation

    def reload_extension(self, name: str) -> ExtensionInstallation | None:
        with self._lock:
            installation = self._extensions.get(name)
            if installation is None:
                return None
            folder = installation.manifest.folder
            workspace_id = installation.workspace_id
            add_panels = installation.add_panels
        return self.install_extension(workspace_id, folder, add_panels=add_panels)

    def _add_custom_panel_locked(self, workspace_id: str, panel: CustomPanelSpec) -> None:
        workspace = self.get_workspace(workspace_id)
        panels = [existing for existing in workspace.ui.custom_panels if existing.id != panel.id]
        panels.append(panel)
        workspace.ui.custom_panels = panels
        workspace.ui.view_revision += 1
        self.workspace_registry.update_workspace(workspace)

    def extension_storage_dir(self, extension_name: str) -> Path:
        installation = self.get_extension(extension_name)
        if installation is None:
            raise ValueError(f"Unknown extension: {extension_name}")
        storage = installation.manifest.folder / "artifacts"
        storage.mkdir(parents=True, exist_ok=True)
        return storage

    def run_tool(
        self,
        uri: str,
        *,
        workspace_id: str,
        params: dict[str, Any] | None = None,
    ) -> Any:
        record = self.tools.get(uri)
        if record is None:
            raise ValueError(f"Unknown tool: {uri}")

        extension_name = record.extension or "default"
        try:
            storage = self.extension_storage_dir(extension_name)
        except ValueError:
            storage = Path.cwd()

        try:
            dataset = self.get_dataset(workspace_id)
        except ValueError:
            dataset = None

        call_params = dict(params or {})
        ctx = RunContext(
            runtime=self,
            workspace_id=workspace_id,
            dataset=dataset,
            params=call_params,
            extension_storage=storage,
            extension_name=extension_name,
        )
        return record.func(ctx, **call_params)

    def snapshot(self, workspace_id: str | None = None) -> dict[str, Any]:
        with self._lock:
            self._sync_panel_module_revisions_locked()
            workspace = self.get_workspace(workspace_id)
            return {
                "runtime_id": self.runtime_id,
                "version": self.version,
                "active_workspace_id": self.workspace_registry.active_workspace_id,
                "extensions": [installation.to_dict() for installation in self.list_extensions()],
                "tools": [record.to_dict() for record in self.tools.list()],
                "workspaces": [
                    {
                        "id": item.id,
                        "dataset_name": item.dataset_name,
                    }
                    for item in self.workspace_registry.list()
                ],
                "workspace": {
                    "id": workspace.id,
                    "dataset_name": workspace.dataset_name,
                    "ui": {
                        "active_layout_key": workspace.ui.active_layout_key,
                        "selected_ids": list(workspace.ui.selected_ids),
                        "similarity_query": (
                            workspace.ui.similarity_query.to_dict()
                            if workspace.ui.similarity_query is not None
                            else None
                        ),
                        "layout_views": {
                            layout_key: view.to_dict()
                            for layout_key, view in sorted(workspace.ui.layout_views.items())
                        },
                        "custom_panels": [
                            {
                                **panel.to_dict(),
                                "data": self.get_panel_payload(workspace.id, panel),
                            }
                            for panel in workspace.ui.custom_panels
                        ],
                        "has_explicit_view": workspace.ui.has_explicit_view,
                        "active_panel_id": workspace.ui.active_panel_id,
                        "view_revision": workspace.ui.view_revision,
                    },
                },
            }
